from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
from pathlib import Path
import json

# === Local imports (safe import fix for Render)
try:
    from .services.calc_core_v12 import CalcCoreV12
    from .services.html_render import HtmlRender
    from .tools.kb_client import KBClient
except ImportError:
    # fallback for Render if "." relative imports fail
    from api.services.calc_core_v12 import CalcCoreV12
    from api.services.html_render import HtmlRender
    from api.tools.kb_client import KBClient


# === Initialize app
app = FastAPI(title="DLENS v12 Gold API", version="12.0")

core = CalcCoreV12()
renderer = HtmlRender()
kb = KBClient()

# === Paths
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
RESOURCES_DIR = PROJECT_ROOT / "resources"

print(f"📂 CURRENT_DIR: {CURRENT_DIR}")
print(f"📦 PROJECT_ROOT: {PROJECT_ROOT}")
print(f"📁 RESOURCES_DIR: {RESOURCES_DIR}")

# === Mount static folder
if RESOURCES_DIR.exists():
    app.mount("/resources", StaticFiles(directory=str(RESOURCES_DIR)), name="resources")
    print(f"✅ Mounted /resources → {RESOURCES_DIR}")
else:
    print("❌ ERROR: resources folder not found!")

# === Request Models
class HuntRequest(BaseModel):
    tickers: List[str]
    as_of_utc: Optional[str] = None
    include_kb: bool = True


class SpotlightRequest(BaseModel):
    ticker: str
    as_of_utc: Optional[str] = None
    include_kb: bool = True


# === ROUTES
@app.get("/")
def home():
    return {
        "message": "DLENS v12 FastAPI running ✅",
        "docs": "/docs",
        "spotlight_view": "/spotlight/view",
        "health": "/health"
    }


@app.get("/health")
def health():
    return {"status": "ok", "standard": "v12"}


@app.post("/hunt/html", response_class=HTMLResponse)
def hunt_html(req: HuntRequest):
    data = core.build_hunt(req.tickers, as_of_utc=req.as_of_utc, include_kb=req.include_kb, kb=kb)
    html = renderer.render_hunt_v12(data)
    return HTMLResponse(content=html)


@app.post("/spotlight/html", response_class=HTMLResponse)
def spotlight_html(req: SpotlightRequest):
    data = core.build_spotlight(req.ticker, as_of_utc=req.as_of_utc, include_kb=req.include_kb, kb=kb)
    html = renderer.render_spotlight_v12(data)
    return HTMLResponse(content=html)


@app.get("/spotlight/view", response_class=HTMLResponse)
def spotlight_view():
    req = SpotlightRequest(ticker="NVDA")
    data = core.build_spotlight(req.ticker, include_kb=True, kb=kb)
    html = renderer.render_spotlight_v12(data)
    return HTMLResponse(content=html)


@app.get("/schemas/{name}")
def get_schema(name: str):
    path = PROJECT_ROOT / "schemas" / f"{name}.json"
    if not path.exists():
        raise HTTPException(404, "schema not found")
    return JSONResponse(json.loads(path.read_text(encoding="utf-8")))
