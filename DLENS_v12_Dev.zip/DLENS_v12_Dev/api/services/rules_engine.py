
from typing import Dict, Any, List

class RulesEngine:
    def apply_cards(self, metrics: Dict[str, Any], cards: List[dict]) -> Dict[str, Any]:
        # Example: verified supply pull-in increases Probability and DUU slightly
        for c in cards:
            for adj in c.get("proposed_adjustments", []):
                field = adj.get("field")
                delta = adj.get("delta", 0)
                if field in metrics and isinstance(metrics[field], (int, float)):
                    metrics[field] = type(metrics[field])(metrics[field] + delta)
        # Recompute derived fields
        csp = 100.0  # placeholder (renderer uses provided CSP)
        mlp = metrics.get("MostLikelyPrice6y", 0.0)
        metrics["Multiple_xCSP"] = round(mlp / csp, 2) if csp else metrics.get("Multiple_xCSP", 0)
        metrics["UpsidePct"] = int((metrics["Multiple_xCSP"] - 1) * 100)
        return metrics
