from jinja2 import Environment, BaseLoader
from datetime import datetime

TEMPLATE_HUNT = """<!doctype html><html><head><meta charset='utf-8'><title>DLENS Hunt v12 Gold</title>
<style>
body{font-family:system-ui,Segoe UI,Arial;padding:16px}
.table{border-collapse:collapse;width:100%;table-layout:fixed}
.table th,.table td{border:1px solid #ddd;padding:6px 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px}
.table th{position:sticky;top:0;background:#f5f7fb}
.small{font-size:12px;color:#555}
.key{margin-top:16px;font-size:12px}
</style></head><body>
<h1>DLENS Hunt v12 Gold — Core Disruptors</h1>
<p class="small">As of {{as_of}} (UTC). DUU ≥ 7; ranked by DUU then DDI. Two-source CSP rule applied.</p>
<table class="table">
<thead><tr>
<th>#</th><th>Company/Ticker</th><th>CSP</th><th>DUU</th><th>DUU (Most-Likely Price, 6y)</th><th>Probability</th><th>×CSP / Upside</th><th>XDLens-E</th><th>XDLens-S</th><th>Science Dep.</th><th>Mix E/S %</th><th>Frogfree</th><th>FEP</th><th>FVU</th><th>DUU ECO</th><th>DDI+Tier</th><th>Notes</th>
</tr></thead>
<tbody>
{% for row in rows %}
<tr>
<td>{{ loop.index }}</td>
<td>{{row.company}} ({{row.ticker}})</td>
<td>${{ '%.2f' % row.csp }}</td>
<td>{{row.DUU}}</td>
<td>${{ '%.2f' % row.MostLikelyPrice6y }}</td>
<td>{{row.ProbabilityPct}}%</td>
<td>{{row.Multiple_xCSP}}× / ~{{row.UpsidePct}}%</td>
<td>{{row.XDLensE}}</td><td>{{row.XDLensS}}</td><td>{{row.ScienceDependency}}</td>
<td>{{row.MixES}}</td><td>{{row.Frogfree}}</td><td>{{row.FEP}}</td><td>{{row.FVU}}</td>
<td>{{row.DUU_ECO}}</td><td>{{row.DDI}} ({{row.Tier}})</td>
<td>KB cards: {{row.kb_cards|length}}</td>
</tr>
{% endfor %}
</tbody></table>

<div class="key">
<strong>Key to Terms:</strong> DUU=Disruptive Upside Unpriced; ×CSP=(Most-Likely Price ÷ CSP); Upside%=(×CSP−1)×100; Frogfree=higher is better; FEP=Founder Execution Premium (1–7 + domain flag); FVU=valuation realism; DDI=Disruption Difficulty Index tiered.
</div>
</body></html>"""

TEMPLATE_SPOTLIGHT = """<!doctype html><html><head><meta charset='utf-8'><title>DLENS Spotlight v12 Gold — {{company}} ({{ticker}})</title>
<style>
body{font-family:system-ui,Segoe UI,Arial;padding:16px;line-height:1.35}
h1{margin:0 0 8px}
small{color:#555}
.section{margin:18px 0;padding:12px;border:1px solid #eee;border-radius:10px;background:#fbfcfe}
table{border-collapse:collapse;width:100%}
td,th{border:1px solid #ddd;padding:6px 8px;font-size:13px}
.code{font-family:ui-monospace,Menlo,Consolas,monospace;background:#f5f7fb;padding:6px 8px;border-radius:6px}
</style></head><body>
<h1>DLENS Spotlight v12 Gold — {{company}} ({{ticker}})</h1>
<small>As of {{as_of}} (UTC). CSP two-source verified.</small>

<div class="section"><strong>At-a-Glance:</strong>
<div class="code">
DUU Score: {{DUU}}/10 → DUU (Most-Likely Price, 6y): ${{'%.2f' % MostLikelyPrice6y}} (= {{Multiple_xCSP}}× CSP ${{'%.2f' % csp}} ≈ ~{{UpsidePct}}%) • Probability: {{ProbabilityPct}}%
</div>
</div>

<div class="section"><strong>Truth Audit:</strong>
<div class="code">Probability {{ProbabilityPct}}% • Utility {{Utility}}/10 • Frogfree {{Frogfree}}/10</div>
<ul>
<li>Key sensitivities & effect sizes summarized</li>
<li>Counter-arguments → brief rebuttals</li>
</ul>
</div>

<div class="section"><strong>Peer Comparison (strict 5-column)</strong>
<table><thead><tr><th>Company</th><th>Technology/Approach</th><th>Scale/Signal</th><th>Subsidy Dependence</th><th>Relative Positioning</th></tr></thead>
<tbody>
<tr><td>{{company}}</td><td>Example tech</td><td>Example scale</td><td>{{Subsidy}}</td><td>Leader in new-paradigm niche</td></tr>
</tbody></table>
</div>

<div class="section"><strong>KB Evidence:</strong>
<small>Applied Insight Cards (last 180 days): {{kb_cards|length}}</small>
<ul>
{% for c in kb_cards %}
<li>{{c.id}} — {{c.source.title}} ({{c.source.type}}; {{c.source.recorded_date}})</li>
{% endfor %}
</ul>
</div>

<div class="section">
<strong>DLENS Gold Resources:</strong>
<ul>
<li><a href="../resources/DLENS_v12_Gold_Definitions_and_Rules_251012.html" target="_blank">Definitions & Rules</a></li>
<li><a href="../resources/DLENS_v12_Gold_Methodology_Notes.html" target="_blank">Methodology Notes</a></li>
<li><a href="../resources/DLENS_v12_Gold_Term_Sheet.html" target="_blank">Term Sheet</a></li>
<li><a href="../resources/DLENS_v12_Gold_Scoring.html" target="_blank">Scoring</a></li>
<li><a href="../resources/DLENS_v12_Gold_Tiers.html" target="_blank">Tiers</a></li>
<li><a href="../resources/DLENS_v12_Gold_Notes_and_Updates.html" target="_blank">Notes & Updates</a></li>
</ul>
</div>

</body></html>"""

class HtmlRender:
    def render_hunt_v12(self, data: dict) -> str:
        env = Environment(loader=BaseLoader())
        tpl = env.from_string(TEMPLATE_HUNT)
        return tpl.render(**data)

    def render_spotlight_v12(self, data: dict) -> str:
        env = Environment(loader=BaseLoader())
        tpl = env.from_string(TEMPLATE_SPOTLIGHT)
        return tpl.render(**data)
