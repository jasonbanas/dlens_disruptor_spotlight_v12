# DLENS v12 Gold — Dev Package
**Date:** 2025-10-12 17:38:43 
**Standard:** v12 Gold (Hunt + Spotlight)

This package upgrades the v10 implementation to **v12 Gold** with unified metrics, Real‑Time Anchoring (two‑source CSP), Subsidy Dependence, Paradigm Comparison, and the **DLENS Knowledge Base (KB) retrieval** interface.

## Contents
- `api/` — FastAPI app, services, providers, and tools (KB).
- `rules/` — v12 rules + example addenda (for v13 workflow).
- `schemas/` — JSON Schemas for /hunt and /spotlight.
- `styles/` — shared CSS tokens for HTML rendering.
- `templates/` — HTML render templates (inline CSS only).
- `examples/` — example JSON payloads and produced HTML/CSV.
- `tests/` — quick checks to validate calculations and schema.
- `kb/` — sample Insight Cards and a tiny JSONL store for local dev.

## Quick Start
1. `pip install -r api/requirements.txt`
2. `uvicorn api.app:app --reload`
3. Open: `http://127.0.0.1:8000/docs`

## Upgrade Notes (v10 → v12)
- **Unified Engine (SSOT):** Hunt and Spotlight share the exact same metric calculations and scores per ticker.
- **Two‑Source CSP Rule:** Quote current stock price from two sources and stamp a UTC timestamp.
- **Hunt v12:** 10 rows, DUU ≥ 7, ranked by DUU then DDI; wide no‑wrap layout; file name `DLENS_Hunt_10x_[YYYYMMDD]_PROD.html`.
- **Spotlight v12:** 12 sections with TradingView widget, strict 5‑column peer table, Truth Audit 3‑line block, Decision‑Ready Conclusion, Compliance Checklist.
- **Metrics:** DUU 0–10; Probability %; Most‑Likely 6‑Year Price; ×CSP and Upside %; Utility 0–10; Frogfree 0–10; FEP 1–7 (+Domain Transportability); FVU 0–10; DUU ECO category; Science Dependency 0–10; XDLens‑E/XDLens‑S; Mix E/S %; DDI + Tier.
- **KB Retrieval:** `/tools/kb_search` internal client fetches Insight Cards to apply rule‑driven adjustments and show citations in outputs.
- **No external CSS/JS:** All HTML is produced with inline CSS only.

## Dev Workflow
- Implement providers in `api/providers/` to fetch CSP (two sources) and company metadata.
- Extend `api/services/calc_core_v12.py` only; avoid duplicating logic elsewhere.
- Use schemas as contracts; examples show valid inputs/outputs.
- Run `pytest` in `tests/` to validate core math and schema conformance.
