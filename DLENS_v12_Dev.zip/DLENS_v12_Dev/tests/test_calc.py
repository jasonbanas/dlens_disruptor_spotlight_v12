
from api.services.calc_core_v12 import CalcCoreV12
from api.tools.kb_client import KBClient

def test_build_spotlight():
    core = CalcCoreV12()
    kb = KBClient()
    data = core.build_spotlight("NVDA", None, True, kb)
    assert data["ticker"] == "NVDA"
    assert "DUU" in data and "ProbabilityPct" in data
