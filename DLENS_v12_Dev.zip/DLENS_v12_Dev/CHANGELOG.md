# Changelog (v12 Gold)
- Initial v12 Gold dev package with unified calc core, two‑source CSP, KB retrieval tool, HTML templates updated for wide layout, Truth Audit block, and strict peer table.
