# DLENS v13 Rule Addendum (Example Draft)
RuleID: V13-R-004 — Partner Validation Rule
Condition: Production PoC w/ Tier-1 partner AND shipping timeline ≤ 12 months AND ScienceDependency ≤ 6
Effect: DUU +1.0, Probability +5%
Scope: Expires after 18 months unless reconfirmed
